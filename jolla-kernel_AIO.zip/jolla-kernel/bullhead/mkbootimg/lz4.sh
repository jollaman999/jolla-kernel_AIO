#!/sbin/sh
echo lz4 > /tmp/split_img/boot.img-ramdiskcomp;
