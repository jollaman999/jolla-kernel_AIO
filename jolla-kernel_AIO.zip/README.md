jolla-kernel_G-AIO bullhead
===========================

jolla-kernel_G All-In-One Aroma Installer


This is flashable zip contens of jolla-kernel_G All-In-One Aroma Installer.

You can choose my jolla-kernel easilly in GUI mode.
Also you can install TWRP recovery.
It support both EXT4 and F2FS.

It suport all of most CM/AOSP based roms.

All of script files in META-INF folder are owned by me.
You can fix it and redestribute it but please leave a repository's URL.
